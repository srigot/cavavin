package fr.rigot.cavavin;

import fr.rigot.cavavin.dummy.DummyContent;
import fr.rigot.cavavin.metier.Vin;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.NavUtils;
import android.view.MenuItem;
import android.widget.TextView;

public class VinDetailActivity extends FragmentActivity {

	TextView libelleNom ;
	Vin vin;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vin_detail);

        getActionBar().setDisplayHomeAsUpEnabled(true);

        if (savedInstanceState == null) {
            Bundle arguments = new Bundle();
            arguments.putString(VinDetailFragment.ARG_ITEM_ID,
                    getIntent().getStringExtra(VinDetailFragment.ARG_ITEM_ID));
            VinDetailFragment fragment = new VinDetailFragment();
            fragment.setArguments(arguments);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.vin_detail_container, fragment)
                    .commit();
        }
        vin = DummyContent.ITEM_MAP.get(
        		getIntent().getStringExtra(VinDetailFragment.ARG_ITEM_ID));
        
        libelleNom = (TextView) findViewById(R.id.libelleNom);
        libelleNom.setText(vin.nom);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            NavUtils.navigateUpTo(this, new Intent(this, VinListActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
