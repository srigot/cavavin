package fr.rigot.cavavin.metier;

public class Vin {
	public String id ;
	public String nom ;
	public Integer annee ;
	
	@Override
	public String toString() {
		return this.nom + " " + this.annee;
	}

	public Vin(String id, String nom, Integer annee) {
		super();
		this.id = id;
		this.nom = nom;
		this.annee = annee;
	}
}
