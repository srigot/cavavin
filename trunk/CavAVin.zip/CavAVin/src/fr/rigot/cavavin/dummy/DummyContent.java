package fr.rigot.cavavin.dummy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.rigot.cavavin.metier.Vin;

public class DummyContent {

    public static List<Vin> ITEMS = new ArrayList<Vin>();
    public static Map<String, Vin> ITEM_MAP = new HashMap<String, Vin>();

    static {
        addItem(new Vin("1", "Vin 1", 2010));
        addItem(new Vin("2", "Vin 2", 2009));
        addItem(new Vin("3", "Vin 3", 2010));
    }

    private static void addItem(Vin item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.id, item);
    }
    
}
