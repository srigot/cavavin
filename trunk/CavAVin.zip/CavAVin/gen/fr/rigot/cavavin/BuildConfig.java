/** Automatically generated file. DO NOT MODIFY */
package fr.rigot.cavavin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}